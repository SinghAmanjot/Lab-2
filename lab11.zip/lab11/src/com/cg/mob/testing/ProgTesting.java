package com.cg.mob.testing;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mob.dto.MobileDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.dao.MobileDaoImp1;
import com.cg.mob.dto.MobileDetails;
import com.cg.mob.util.MyStringDateUtil;

import junit.framework.Assert;

public class ProgTesting {

	    static MobileDetails md = new MobileDetails("Harry","hajen12@gmail.com","9992939495",1002,LocalDate.now());
		static MobileDaoImp1 mimp = new MobileDaoImp1();
		
		
		@BeforeClass
		public static void setUp()
		{
		    mimp = new MobileDaoImp1();
			System.out.println(" This Function is called once before the execution of all the test cases");
		}
		
		@AfterClass
		public static void tearDown()
		{
			mimp=null;
			System.out.println(" This Function is called once After the execution of all the test cases");
		}
		
		@Before
		public void init()
		{
			System.out.println(" This Function is called once before the execution of each test case");
		}
		
		@After
		public void destroy()
		{
			System.out.println(" This Function is called once After the execution of each test case");
		}
		
		@Test
		public void insertTest1()
		{
			//LocalDate d = LocalDate.now();
			//md = new MobileDetails("Jenny","jen12@gmail.com","9192939495",1005,231454,d);
			try {
				Assert.assertEquals(1, mimp.InsDetails(md));
			} 
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
		

		
		@Test
		public void deleteTest()
		{
			//LocalDate d = LocalDate.now();
			//md = new MobileDetails("Harry","hajen12@gmail.com","9992939495",1002,221454,d);
			try {
				Assert.assertEquals(1, mimp.deleteMob(md.getMobId()));
			} catch (IOException | MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
}
