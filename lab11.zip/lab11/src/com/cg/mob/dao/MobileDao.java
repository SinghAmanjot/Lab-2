package com.cg.mob.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mob.dto.MobileDetails;
import com.cg.mob.exception.MobileException;

public interface MobileDao {
	
	public int InsDetails(MobileDetails md) throws SQLException, IOException, MobileException, Exception;

	public int UpdateTable();
	
	public ArrayList<MobileDetails> getAllPur() throws IOException, Exception;
	
	public ArrayList<MobileDetails> getAllMob() throws SQLException;
	
	public int deleteMob(int mobId) throws IOException, MobileException;
	
	public ArrayList<MobileDetails> mobByPrice(int a, int b);
	
	public ArrayList<MobileDetails> getMobid();
	
	public int updatequ(int q, int mobId);
	
	public int mobByQ(int q);
	
}
