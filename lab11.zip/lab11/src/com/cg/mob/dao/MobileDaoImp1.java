package com.cg.mob.dao;

import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mob.dto.MobileDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.util.DBUtil;
import com.cg.mob.util.MyStringDateUtil;



public class MobileDaoImp1 implements MobileDao{

	
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Logger Moblogger = null;

	int dataInserted = 0;
	int dataDeleted = 0;
	int dataDecreased = 0;
	
	
	
	public MobileDaoImp1() {
		PropertyConfigurator.configure("C:\\Demo\\lab11\\src\\log4j.properties");
		Moblogger = Logger.getLogger(MobileDaoImp1.class);
	}

	@Override
	public int InsDetails(MobileDetails md) throws IOException, MobileException, Exception {
		
		ArrayList<MobileDetails> list1 = new ArrayList<MobileDetails>();
		list1 = getMobid();
	
		if(list1.contains(md.getMobId())) {
		java.sql.Date sqlDOP = MyStringDateUtil.fromLocalToSqlDate(md.getpDate());
		con = DBUtil.getCon();
		
		Moblogger.info("Connection Established for InsDetails()");
		
		System.out.println("con = "+con);//if null connection not estd
	
		    pst =  con.prepareStatement(QueryMapper.RETURN_QUANTITY);
		    pst.setInt(1, md.getMobId());
		    rs = pst.executeQuery();
		    rs.next();
		    int quantity = rs.getInt(1);
		    
		    if(quantity>0)
		    {
			pst =  con.prepareStatement(QueryMapper.INSERT_QRY);
		
			pst.setString(1, md.getCustName());
			pst.setString(2,md.getMailId());
			pst.setString(3, md.getPhNm());
			pst.setDate(4, sqlDOP);
			pst.setInt(5, md.getMobId());
			dataInserted = pst.executeUpdate();
			
			pst =  con.prepareStatement(QueryMapper.MOB_UPDATE);
			pst.setInt(1, quantity-1);
			pst.setInt(2, md.getMobId());
			pst.executeUpdate();
			
		    }}
		else
		{
			System.out.println("Invalid Mobile ID");
		}
		Moblogger.info("Executed InsDetails()");
	return dataInserted;
	
	}
	
	@Override
	public int UpdateTable() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<MobileDetails> getAllPur() throws IOException, Exception {
		
		ArrayList list = new ArrayList();
		con = DBUtil.getCon();
		Moblogger.info("Connection Established for getAllPur()");
		pst =  con.prepareStatement(QueryMapper.SELECTALL);
		rs =   pst.executeQuery();

		while(rs.next())
		{
			//System.out.println(rs.getInt("putchaseId")+"\t\t"+rs.getString("Customer_name")+"\t\t"+rs.getString("mail_id")+"\t\t"+rs.getString("Phone Number")+"\t\t"+rs.getInt("mobile ID"));
			System.out.println(rs.getString("cname")+"\t\t"+rs.getString("mailid")+"\t\t"+rs.getString("Phoneno")+"\t\t"+rs.getInt("putchaseId")+"\t\t"+rs.getInt("mobileid")+"\t\t"+rs.getDate("purchasedate"));
			//System.out.println(rs.getInt("putchaseId")+"\t\t"+rs.getString("Customer_name")+"\t\t"+rs.getString("mail_id")+"\t\t"+rs.getString("Phone Number")+"\t\t"+rs.getDate("Date")+"\t\t"+rs.getInt("mobile ID"));
		}
		
		Moblogger.info("gteAllPur() Executed");
		return list;
	}
	
	@Override
	public ArrayList<MobileDetails> getAllMob() throws SQLException {

		Moblogger.info("Connection Established for getAllMob()");
		ArrayList list = new ArrayList();
		try {
		con = DBUtil.getCon();
		pst =  con.prepareStatement(QueryMapper.ALL_MOBILES);
		rs =   pst.executeQuery();
		} 
		catch (SQLException | IOException e) 
		{
			e.printStackTrace();
		}
		
		while(rs.next())
		{
			System.out.println(rs.getInt("mobileid")+"\t\t\t\t"+rs.getString("name")+"\t\t\t\t"+rs.getInt("price")+"\t\t\t\t"+rs.getInt("quantity"));
		}

		Moblogger.info("getAllMob() Executed");
		return list;
	}
	
	@Override
	public int deleteMob(int mobileId) throws IOException, MobileException {
		
		try {
			con = DBUtil.getCon();
			
			pst =  con.prepareStatement(QueryMapper.MID_NULL);
			pst.setInt(1, mobileId);
			int i =pst.executeUpdate();
			
			pst =  con.prepareStatement(QueryMapper.DEL_QRY);
			pst.setInt(1, mobileId);
			dataDeleted = pst.executeUpdate();
			
			}
		
			catch (SQLException e) {
				
				throw new MobileException(e.getMessage());
			}
			
		    Moblogger.info("deleteMob() Executed");
			return dataDeleted;
	}
	

	@Override
	public ArrayList<MobileDetails> mobByPrice(int a, int b) {

		ArrayList list = new ArrayList();
		try {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.RANGE);
		pst.setInt(1, a);
		pst.setInt(2, b);
		rs = pst.executeQuery();
		System.out.println("MOBILE ID\t\tNAME\t\tPRICE\t\tQUANTITY");
		while(rs.next())
		{
			System.out.println(rs.getInt("mobileid")+"\t\t"+rs.getString("name")+"\t\t"+rs.getInt("price")+"\t\t"+rs.getInt("quantity"));
		}
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<MobileDetails> getMobid() {

		ArrayList list = new ArrayList();
		try {
		con = DBUtil.getCon();
		pst = con.prepareStatement("SELECT MOBILEID FROM MOBILES");
		rs = pst.executeQuery();
		while(rs.next())
		{
			list.add(rs.getInt(1));
		}
		}
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public int updatequ(int q, int mobId) {
		
		try 
		{
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.DEC_Q);
			pst.setInt(1, q);
			pst.setInt(2, mobId);
			dataDecreased = pst.executeUpdate();
			
		} 
		catch (SQLException | IOException e) 
		{
			e.printStackTrace();
		}
		
		
		return dataDecreased;
	}

	@Override
	public int mobByQ(int q) {

		try {
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.QUANTITY);
			pst.setInt(1, q);
			rs = pst.executeQuery();
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getInt(3)+"\t\t"+rs.getInt(4));
			}
		} 
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		
		return 0;
	}

}

























