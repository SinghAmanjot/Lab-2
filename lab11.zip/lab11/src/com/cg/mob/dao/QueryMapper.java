package com.cg.mob.dao;

public interface QueryMapper {

	public static final String INSERT_QRY="INSERT into purchasedetails (putchaseid, cname, mailid, phoneno, purchasedate,mobileid) values(putchaseid.nextval,?,?,?,?,?)"; 
	
	public static final String SELECTALL="SELECT * FROM purchasedetails"; 
	
	public static final String ALL_MOBILES="SELECT * FROM MOBILES"; 
	
	public static final String DEL_QRY="DELETE FROM mobiles WHERE mobileid=?";
	
	public static final String RETURN_QUANTITY = "SELECT QUANTITY FROM MOBILES WHERE MOBILEID = ?";
	
	public static final String MOBILE_RETURN_ID = "SELECT MOBILEID FROM MOBILES";
	
	public static final String MOB_UPDATE = "UPDATE MOBILES SET QUANTITY = ? WHERE MOBILEID = ?";
	
	public static final String MID_NULL = "UPDATE PURCHASEDETAILS SET MOBILEID = NULL WHERE MOBILEID = ?";
	
	public static final String RANGE = "SELECT * FROM MOBILES WHERE PRICE BETWEEN ? AND ?"; 
	
	public static final String DEC_Q = "UPDATE MOBILES SET QUANTITY = ? WHERE MOBILEID = ?";
	
	public static final String QUANTITY = "SELECT * FROM MOBILES WHERE QUANTITY > ?";
}



/*create sequence seq
 *start with 1
 *maxvalue 1000
 *increment by 1
 *nocycle;
 *
 */