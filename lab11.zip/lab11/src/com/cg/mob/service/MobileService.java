package com.cg.mob.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.mob.dto.MobileDetails;
import com.cg.mob.exception.MobileException;

public interface MobileService {
	
	public int InsDetails(MobileDetails md) throws SQLException, IOException, MobileException, Exception;

	public int UpdateTable();
	
	public ArrayList<MobileDetails> getAllPur() throws Exception, Exception;
	
	public ArrayList<MobileDetails> getAllMob() throws SQLException;
	
	public int deleteMob(int mobileId) throws  Exception;
	
	public ArrayList<MobileDetails>  mobByPrice(int a, int b);
	
	boolean validateCName(String cname) throws MobileException;
	
	boolean validatephn(String ph) throws MobileException;

	boolean validatemail(String mld) throws MobileException;
	
	boolean validatemobileid(int mid) throws MobileException;
	
	public int updatequ(int q, int mobId);
	
	public int mobByQ(int q);

}


