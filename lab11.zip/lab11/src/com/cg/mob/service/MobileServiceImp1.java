package com.cg.mob.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mob.dao.MobileDao;
import com.cg.mob.dao.MobileDaoImp1;
import com.cg.mob.dto.MobileDetails;
import com.cg.mob.exception.MobileException;

public class MobileServiceImp1 implements MobileService{
	
	MobileDao mDao = null;
	
	
	public MobileServiceImp1() {
		
		mDao = new MobileDaoImp1();
	}

	@Override
	public int InsDetails(MobileDetails md) throws Exception {
		
		return mDao.InsDetails(md);
	}

	
	@Override
	public int UpdateTable() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<MobileDetails> getAllPur() throws Exception, Exception {
		// TODO Auto-generated method stub
		return mDao.getAllPur();
	}
	
	@Override
	public ArrayList<MobileDetails> getAllMob() throws SQLException {
		// TODO Auto-generated method stub
		return mDao.getAllMob();
	}

	@Override
	public int deleteMob(int mobileId) throws  Exception {
		// TODO Auto-generated method stub
		return mDao.deleteMob(mobileId);
	}

	@Override
	public ArrayList<MobileDetails> mobByPrice(int a, int b) {
		// TODO Auto-generated method stub
		return mDao.mobByPrice(a, b);
	}

	@Override
	public boolean validateCName(String cname) throws MobileException {
		
		String s1 = "[A-Z][a-z]+";
		if(Pattern.matches(s1,cname))
		{
			return true;
		}
		else
		{
			throw new MobileException("Invalid CusName, Start with capital letter");
		}
	}
	
	
	@Override
	public boolean validatemail(String mld) throws MobileException {
		// TODO Auto-generated method stub
		String s1 = "[a-zA-Z0-9_.-]{4,20}[@]{1}[A-Z a-z . ]{3,}";
		if(Pattern.matches(s1,mld))
		{
			return true;
		}
		else
		{
			throw new MobileException("Invalid EmailID");
		}
	}

	@Override
	public boolean validatemobileid(int mid) throws MobileException {

		String midd = new Integer(mid).toString();
		String s1 = "[0-9]{4}";
		if(Pattern.matches(s1,midd))
		{
			return true;
		}
		else
		{
			throw new MobileException("Invalid mobile id");
		}
	}

	@Override
	public boolean validatephn(String ph) throws MobileException {
		String s1 = "[0-9]{10}";
		if(Pattern.matches(s1,ph))
		{
			return true;
		}
		else
		{
			throw new MobileException("Invalid phone number");
		}
	}

	@Override
	public int updatequ(int q, int mobId) {
	
		return mDao.updatequ(q, mobId);
	}

	@Override
	public int mobByQ(int q) {
		
		return mDao.mobByQ(q);
	}

	
	

}
