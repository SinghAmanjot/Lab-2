package com.cg.mob.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mob.dao.MobileDaoImp1;
import com.cg.mob.dto.MobileDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.service.MobileService;
import com.cg.mob.service.MobileServiceImp1;

public class TestMobMgm {

	static Scanner sc = new Scanner(System.in);//Static because we have to use it in static function 
	static MobileService mserv = null;
	static Logger TestMobLogger = null;
	

	public static void main(String[] args) throws Exception {
		
		System.out.println("main Starts here");
		
		mserv = new MobileServiceImp1();
	
		PropertyConfigurator.configure("C:\\Demo\\lab11\\src\\log4j.properties");
		TestMobLogger = Logger.getLogger(TestMobMgm.class);
		
		int choice;
		
		while(true)
		{
	
			System.out.println(" 1:Insert Purchase Details\n 2:Fetch Purchase Details\n 3:Fetch mobile table\n 4:Delete Details by mobile id \n "
					+ "5:Search mobiles based on price range\n 6: Search Mobile by quantity\n 7: Change quantity by (input)\n 8:Exit");
			choice = sc.nextInt();
			
			switch(choice)
			{
			case 1:InsDetails();break;
			case 2:getAllPur();break;
			case 3:getAllMob();break;
			case 4:deleteMob();break;
			case 5:mobByPrice();break;
			case 6:mobByQuan();break;
			case 7:ChangeQuan();break;
			case 8:exit();break;
			default :System.exit(1);
			}
		}

     }
	
	private static void mobByQuan() {
		System.out.println("Enter quantiy");
		int m = sc.nextInt();
	    mserv.mobByQ(m);
	}
	
	private static void ChangeQuan() {
		
		System.out.println("Enter mobileid");
		int m = sc.nextInt();
		System.out.println("Enter new Quantity");
		int que = sc.nextInt();
		mserv.updatequ(que, m);	
	}

	private static void exit()
	{
		System.exit(0);
	}
	
	private static void mobByPrice()
	{
		System.out.println("Enter floor value");
		int floor = sc.nextInt();
		System.out.println("Enter ceiling value");
		int ceiling = sc.nextInt();
		mserv.mobByPrice(floor, ceiling);
	}
	

	private static void  deleteMob() throws Exception, Exception {
		
		TestMobLogger.warn("delete Mob called");
		
		System.out.println("Enter Mobile ID:");
		int mid = sc.nextInt();
		mserv.deleteMob(mid);
		System.out.println("Deleted mobile data");
	}
	
	private static void InsDetails() throws Exception {
	
		
		System.out.println("Enter customer name");
		String cname = sc.next();
		LocalDate strDOP = LocalDate.now();
		         
		if(mserv.validateCName(cname)) {
				System.out.println("Enter customer mailid");
		        String mailid = sc.next();
		        
		      
				        System.out.println("Enter customer phone number");
		                String pn = sc.next();
		               
		                if(mserv.validatephn(pn)) {
			            		     
		                	         System.out.println("Enter mobileId");
			            		     int mid = sc.nextInt();
		                             
		
		                            	 MobileDetails mm = new MobileDetails(cname, mailid, pn, mid, strDOP);
		                            	 int dataAdd = mserv.InsDetails(mm);
		                            	 if (dataAdd==1)
		                     	        {
		                     	        	System.out.println("Data inserted");
		                     	        }
		                     	        else
		                     	        {
		                     	        	System.out.println("Some error in Insert");
		                     	        }
		                             }}
		
	}
	
	private static void getAllPur() throws Exception
	{
	   TestMobLogger.fatal("get All Pur called");
	   
       ArrayList<MobileDetails> l1 = new ArrayList<MobileDetails>();
		
			try {
				l1 = mserv.getAllPur();
			}
			catch (MobileException e) {
			
				System.out.println(e.getMessage());
			}
			for(MobileDetails x: l1)
				System.out.println(x);		
	}
	
	private static void getAllMob() throws Exception
	{
	   TestMobLogger.info("getAllMob called");
       ArrayList<MobileDetails> l1 = new ArrayList<MobileDetails>();
		
			l1 = mserv.getAllMob();
			for(MobileDetails x: l1)
				System.out.println(x);		
	}
	
}
