package com.cg.mob.dto;

import java.time.LocalDate;

public class MobileDetails {
	
	private String custName;
	private String mailId;
	private String phNm;
	private int mobId;
	private int pId;//toBe generated automaticly
	private LocalDate pDate;//current system date
	//cname, mailid, pn, mid, pid, strDOP
	public MobileDetails(String custName, String mailId, String phNm, int mobId, LocalDate pDate) {
		super();
		this.custName = custName;
		this.mailId = mailId;
		this.phNm = phNm;
		this.mobId = mobId;
		this.pId = pId;
		this.pDate = pDate;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhNm() {
		return phNm;
	}
	public void setPhNm(String phNm) {
		this.phNm = phNm;
	}
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public LocalDate getpDate() {
		return pDate;
	}
	public void setpDate(LocalDate pDate) {
		this.pDate = pDate;
	}
	
	
	
}
